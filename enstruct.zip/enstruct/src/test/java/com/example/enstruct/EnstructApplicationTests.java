package com.example.enstruct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnstructApplicationTests {

	@Test
	void contextLoads() {
	}

}
