package com.example.enstruct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnstructApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnstructApplication.class, args);
	}

}
